using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleManager : MonoBehaviour
{
    public void OnToTownButton()
    {
        SoundsManager.instance.PlaySE(0);
    }
}
