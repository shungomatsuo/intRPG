using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TownManager : MonoBehaviour
{
  public void OnToQuestButton()
    {
        SoundsManager.instance.PlaySE(0);
    }
}
