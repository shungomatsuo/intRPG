using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;


public class QuestManager : MonoBehaviour
{
    public StageUIManager stageUI;
    public GameObject enemyPrefab;
    public BattleManager battleManager;
    public SceneTransitionManager sceneTransitionManager;
    public GameObject questBG;
    int[] encountTable = { -1, -1, 0, -1, 0, -1, -1 };
    int currentStage = 0;

    private void Start()
    {
        stageUI.UpdateUI(currentStage);
    }
 IEnumerator Searching()
    {
        // �w�i��傫��
        questBG.transform.DOScale(new Vector3(1.5f, 1.5f, 1.5f), 2f)
                .OnComplete(() => questBG.transform.localScale = new Vector3(1, 1, 1));
        // �t�F�[�h�A�E�g
        SpriteRenderer questBGSpriteRenderer = questBG.GetComponent<SpriteRenderer>();
        questBGSpriteRenderer.DOFade(0, 2f)
                .OnComplete(() => questBGSpriteRenderer.DOFade(1, 0));
        yield return new WaitForSeconds(2f);
        currentStage++;

        stageUI.UpdateUI(currentStage);

        if (encountTable.Length <= currentStage)
        {
            
            Debug.Log("�N�G�X�g�N���A");
            QuestClear();
        }
        else if (encountTable[currentStage] == 0)
        {
            EncountEnemy();
        }
        else
        {
            stageUI.ShowButtons();
        }
    }

    public void OnNextButton()
    {
        SoundsManager.instance.PlaySE(0);
        stageUI.HideButtons();
        StartCoroutine(Searching());
       
    }
    public void OnToTownButton()
    {
        SoundsManager.instance.PlaySE(0);
    }
    void EncountEnemy()
    {
        stageUI.HideButtons();
        GameObject enemyObj = Instantiate(enemyPrefab);
        EnemyManager enemy = enemyObj.GetComponent<EnemyManager>();
        battleManager.Setup(enemy);
    }

    public void EndBattle()
    {
        stageUI.ShowButtons();
    }

    void QuestClear()
    {
        SoundsManager.instance.StopBGM();
        SoundsManager.instance.PlaySE(2);
        // �N�G�X�g�N���A�ƕ\������
        // �X�ɖ߂�{�^���̂ݕ\������
        stageUI.ShowClearText();


        // sceneTransitionManager.LoadTo("Town");
    }
}


