using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StageUIManager : MonoBehaviour
{
    public Text StageText;
    public GameObject nextButton;
    public GameObject ToTownButton;
    public GameObject StageClearImage;

    private void Start()
    {
        StageClearImage.SetActive(false);
    }


    public void UpdateUI(int currentStage)
    {
        StageText.text = string.Format("�X�e�[�W:{0}", currentStage+1);
    }
    public void HideButtons()
    {
        nextButton.SetActive(false);
        ToTownButton.SetActive(false);
    }
    public void ShowButtons()
    {
        nextButton.SetActive(true);
        ToTownButton.SetActive(true);
    }
    public void ShowClearText()
    {
        StageClearImage.SetActive(true);
        nextButton.SetActive(false);
        ToTownButton.SetActive(true);
    }
   
}
